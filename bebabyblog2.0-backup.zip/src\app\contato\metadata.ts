export const metadata = {
  title: 'Suporte e Contato – Bebaby Blog',
  description: 'Fale com a equipe do Bebaby Blog. Tire dúvidas ou envie sugestões.',
}; 