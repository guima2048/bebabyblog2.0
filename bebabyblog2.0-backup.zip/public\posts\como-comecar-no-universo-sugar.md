---
title: Como começar no universo Sugar
date: 2025-06-01
videoUrl: https://www.youtube.com/embed/dQw4w9WgXcQ
---

Esse é um exemplo de conteúdo do post escrito em **Markdown**.  
Você pode adicionar listas, títulos, imagens e mais aqui. 