// config/seo.ts
export const siteSEO = {
  googleVerification: 'código-verificação-aqui',
  gaId: 'G-XXXXXXXXXX'
}; 